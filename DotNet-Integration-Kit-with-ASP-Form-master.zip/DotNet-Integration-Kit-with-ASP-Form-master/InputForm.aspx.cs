﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class InputForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //public decimal formatAmount(decimal amount, string decimalPlaces)
    //{
    //    string format = String.Format("{{0:N{0}}}", decimalPlaces);
    //    amount = Math.Round(amount);
    //    string valuestring = String.Format(format, amount);

    //    valuestring = valuestring.Replace("\\.", "");
    //    return Convert.ToDecimal(valuestring);
    //}
}